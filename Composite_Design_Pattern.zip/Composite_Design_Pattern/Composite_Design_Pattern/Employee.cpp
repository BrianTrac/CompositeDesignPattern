#include "Employee.h"

Employee::Employee() {}

Employee::Employee(std::string _name, std::string _ID, int _salary) :
	name(_name), ID(_ID), salary(_salary) {
}

std::string Employee::belowStructure() const {
	std::ostringstream oss;
	oss  << "Employee{name=" << name << "}";
	
	return oss.str();
}

bool Employee::isComposite() const {
	return false;
}

std::ostream& operator << (std::ostream& os, const Employee& employee) {
	os << "Employee{name=" << employee.name << ", ID=" << employee.ID << ", salary=" << std::to_string(employee.salary) << "}\n";
	return os;
}