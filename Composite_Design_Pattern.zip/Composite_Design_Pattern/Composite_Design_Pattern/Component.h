#pragma once

#include "string"

class Component {
protected:
	Component* parent;
public:
	virtual ~Component();
	void setParent(Component* _parent);
	Component* getParent() const;
	virtual void add(Component* component) {}
	virtual void remove(Component* component) {}
	virtual bool isComposite() const = 0;
	virtual std::string belowStructure() const = 0;
};
