#include "ManagerOfCompany.h"

ManagerOfCompany::ManagerOfCompany() {}

void ManagerOfCompany::viewStructure(Component* component) {
	std::cout << component->belowStructure() << "\n\n";
}

void ManagerOfCompany::run() {
	Component* company = new Department("Cty KTHN");

	Component* department_1 = new Department("CNTN");
	Component* employee_1 = new Employee("Nguyen Van A", "GVCNTN001", 30000);
	Component* employee_2 = new Employee("Nguyen Van B", "GVCNTN002", 40000);
	Component* employee_3 = new Employee("Nguyen Van C", "GVCNTN003", 50000);
	department_1->add(employee_1);
	department_1->add(employee_2);
	department_1->add(employee_3);

	Component* department_2 = new Department("ToanTin");
	Component* department_3 = new Department("KHDL");
	Component* employee_4 = new Employee("Nguyen Van D", "GVTT004", 30000);
	Component* employee_5 = new Employee("Nguyen Van E", "GVKHDL005", 40000);
	department_3->add(employee_4);
	department_2->add(department_3);
	department_2->add(employee_5);

	company->add(department_1);
	company->add(department_2);

	std::cout << "Structure of Company: \n";
	viewStructure(company);
}
