#include "Department.h"

Department::Department() {}

Department::Department(std::string _name) {
	name = _name;
}

std::string Department::getName() {
	return name;
}

void Department::add(Component* component) {
	this->children.push_back(component);
	component->setParent(this);
}

void Department::remove(Component* component) {
	auto it = std::find(children.begin(), children.end(), component);
	if (it != children.end()) {
		children.erase(it);
		component->setParent(nullptr);
	}
}

bool Department::isComposite() const {
	return true;
}

std::string Department::belowStructure() const {
	std::string result;
	count++;

	for (size_t i = 0; i < children.size(); i++) {
		if (!children[i]->isComposite()) {
			for (int k = 0; k < count; k++)
				result += "\t";
		}
		result += children[i]->belowStructure() + "\n";
	}

	std::string tmp = "\"" + name + "\": {\n";
	if (getParent() != nullptr && getParent()->isComposite()) {
		for (int k = 0; k < count - 1; k++)
			tmp = "\t" + tmp;
	} 
	result = tmp + result;
	if (getParent() != nullptr && getParent()->isComposite()) {
		for (int k = 0; k < count - 1; k++)
			result = result + "\t";
	}
	result += "}";

	count--;
	return result;
}