#pragma once

#include "Component.h"
#include <string>
#include <sstream>
#include <iostream>

class Employee : public Component{
private:
	std::string name;
	std::string ID;
	int salary;
public:
	Employee();
	Employee(std::string _name, std::string ID, int _salary);
	friend std::ostream& operator << (std::ostream & os, const Employee & employee);
public:
	bool isComposite() const override;
	std::string belowStructure() const override;
};



