#pragma once

#include "Component.h"
#include <vector>
#include <string>

static int count = 0;
class Department : public Component {
protected: 
	std::vector<Component*> children;
	std::string name;
public:
	Department();
	Department(std::string _name);
	std::string getName();
	void add(Component* component) override;
	void remove(Component* component) override;
	bool isComposite() const override;
	std::string belowStructure() const override;
};

