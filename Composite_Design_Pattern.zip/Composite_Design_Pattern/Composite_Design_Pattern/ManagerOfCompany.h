#pragma once

#include "Component.h"
#include "Employee.h"
#include "Department.h"

class ManagerOfCompany {
public:
	ManagerOfCompany();
	void viewStructure(Component* component);
	void run();
};
