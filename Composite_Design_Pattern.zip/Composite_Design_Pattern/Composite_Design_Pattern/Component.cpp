#include "Component.h"

Component::~Component() {
	delete parent;
}

void Component::setParent(Component* _parent) {
	this->parent = _parent;
}

Component* Component::getParent() const {
	return this->parent;
}