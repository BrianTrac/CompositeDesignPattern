#include "ManagerOfCompany.h"

int main() {

	ManagerOfCompany managerOfCompany;
	managerOfCompany.run();

	return 0;
}